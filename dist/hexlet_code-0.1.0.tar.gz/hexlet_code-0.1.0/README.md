### Hexlet tests and linter status:
[![Actions Status](https://github.com/Eric-tech777/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Eric-tech777/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/8c84186eb2f8ea4fa106/maintainability)](https://codeclimate.com/github/Eric-tech777/python-project-49/maintainability)
https://asciinema.org/connect/cbd4e25d-11c3-4555-ad24-f4906c663963
https://asciinema.org/a/Z1EDhurFB7HBFHNkVGXVDgEt6
https://asciinema.org/a/KhPAKxo8mmJQa40EtxrFPHRnm
https://asciinema.org/a/myPUTDmInUrXnhtqmnOSUH6Kn




