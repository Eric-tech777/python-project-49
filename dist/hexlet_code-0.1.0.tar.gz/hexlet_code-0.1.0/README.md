### Hexlet tests and linter status:
[![Actions Status](https://github.com/Eric-tech777/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Eric-tech777/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/8c84186eb2f8ea4fa106/maintainability)](https://codeclimate.com/github/Eric-tech777/python-project-49/maintainability)
https://asciinema.org/a/BZkRUDYw0UBCCVlNfCq3Te5u6
https://asciinema.org/a/BZkRUDYw0UBCCVlNfCq3Te5u6
https://asciinema.org/a/RnXxNYduhDHuSANOoZfejzxZx
https://asciinema.org/a/IVwHTHLKfqB7sV4nWnxUV7c02
https://asciinema.org/a/jVPDATc63p6soqhM0pHYMpfaM






