### Hexlet tests and linter status:
[![Actions Status](https://github.com/Eric-tech777/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Eric-tech777/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/8c84186eb2f8ea4fa106/maintainability)](https://codeclimate.com/github/Eric-tech777/python-project-49/maintainability)
