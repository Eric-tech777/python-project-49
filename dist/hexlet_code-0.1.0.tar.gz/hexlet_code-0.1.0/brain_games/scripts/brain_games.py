#!/usr/bin/env python3
# from brain_games import cli
from .brain_even import guess_even


def main():
    print('Welcome to the Brain Games!')
    # cli.welcome_user()
    guess_even()


if __name__ == '__main__':
    main()
